#pragma once

#include "PollutionArea.h"

class AirPollution : public PollutionArea
{
public:
    AirPollution(int x, int y);

private:
};