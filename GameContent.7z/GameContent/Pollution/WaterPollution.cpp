#include "WaterPollution.h"

WaterPollution::WaterPollution() :
    PollutionArea(WATER_POLLUTION, WATER_POLLUTION_DECREASE_RATE)
{
}