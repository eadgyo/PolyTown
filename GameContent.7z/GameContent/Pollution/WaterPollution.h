#pragma once

#include "PollutionArea.h"

class WaterPollution : public PollutionArea
{
public:
    WaterPollution();

private:
};