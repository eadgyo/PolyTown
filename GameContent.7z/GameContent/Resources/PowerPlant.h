#ifndef POWER_PLANT_H
#define POWER_PLANT_H

#include "Resources.h"

class PowerPlant : public Resources
{
public:
    PowerPlant(std::string name, int x, int y);

private:

};

#endif // !POWER_PLANT_H