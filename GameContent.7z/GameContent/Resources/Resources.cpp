#include "Resources.h"

Resources::Resources()
{
}