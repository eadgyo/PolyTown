#ifndef WATER_TOWER_H
#define WATER_TOWER_H

#include "Resources.h"

class WaterTower : public virtual Resources
{
public:
    WaterTower(int x, int y);

private:

};

#endif // ! WATER_TOWER_H